-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 14:43
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC),
DROP INDEX `fk_vendaosproduto_local1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD COLUMN `id_condicao` BIGINT(11) NULL DEFAULT NULL AFTER `id_empresa`,
ADD COLUMN `id_lancamento` BIGINT(11) NULL DEFAULT NULL AFTER `id_condicao`,
ADD COLUMN `id_meio` BIGINT(11) NULL DEFAULT NULL AFTER `id_lancamento`,
ADD INDEX `fk_natureza_condicao1_idx` (`id_condicao` ASC),
ADD INDEX `fk_natureza_lancamento1_idx` (`id_lancamento` ASC),
ADD INDEX `fk_natureza_meio1_idx` (`id_meio` ASC);

ALTER TABLE `expresso`.`natureza` 
ADD CONSTRAINT `fk_natureza_condicao1`
  FOREIGN KEY (`id_condicao`)
  REFERENCES `expresso`.`condicao` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_natureza_lancamento1`
  FOREIGN KEY (`id_lancamento`)
  REFERENCES `expresso`.`lancamento` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_natureza_meio1`
  FOREIGN KEY (`id_meio`)
  REFERENCES `expresso`.`meio` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (27);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
