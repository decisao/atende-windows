-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 14:42
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `federalnac` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `cest`,
ADD COLUMN `federalimp` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalnac`,
ADD COLUMN `estadual` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalimp`,
ADD COLUMN `municipal` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `estadual`;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (17);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
