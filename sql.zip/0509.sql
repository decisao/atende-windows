
ALTER TABLE `compra` 
ADD COLUMN `rateiofretecusto` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`,
ADD COLUMN `rateiooutroscusto` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `rateiofretecusto`;
