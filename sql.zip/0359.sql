
ALTER TABLE `usuario`
	ADD UNIQUE INDEX `cpf_UNIQUE` (`cpf`);