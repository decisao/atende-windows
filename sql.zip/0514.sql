
ALTER TABLE `vendaos` 
ADD COLUMN `id_local` BIGINT(11) NOT NULL AFTER `id_natureza`,
ADD INDEX `fk_vendaos_local1_idx` (`id_local` ASC);
;

ALTER TABLE `vendaos` 
ADD CONSTRAINT `fk_vendaos_local1`
  FOREIGN KEY (`id_local`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;