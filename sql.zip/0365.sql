
ALTER TABLE `transferenciaproduto` 
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`,
ADD COLUMN `codbarra` VARCHAR(13) NOT NULL AFTER `nome`,
ADD COLUMN `unidade` CHAR(2) NOT NULL AFTER `codbarra`;