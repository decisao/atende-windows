
ALTER TABLE `atualizacao` 
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `data`);
;