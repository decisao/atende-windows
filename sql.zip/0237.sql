-- MySQL Workbench Synchronization
-- Generated: 2017-09-07 11:32
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_osstatus$aberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$autorizada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$iniciada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$nautorizada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$entregue` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$fechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD INDEX `fk_empresa_osstatus1_idx` (`id_osstatus$aberta` ASC),
ADD INDEX `fk_empresa_osstatus2_idx` (`id_osstatus$autorizada` ASC),
ADD INDEX `fk_empresa_osstatus3_idx` (`id_osstatus$iniciada` ASC),
ADD INDEX `fk_empresa_osstatus4_idx` (`id_osstatus$nautorizada` ASC),
ADD INDEX `fk_empresa_osstatus5_idx` (`id_osstatus$entregue` ASC),
ADD INDEX `fk_empresa_osstatus6_idx` (`id_osstatus$fechada` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_osstatus1`
  FOREIGN KEY (`id_osstatus$aberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus2`
  FOREIGN KEY (`id_osstatus$autorizada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus3`
  FOREIGN KEY (`id_osstatus$iniciada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus4`
  FOREIGN KEY (`id_osstatus$nautorizada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus5`
  FOREIGN KEY (`id_osstatus$entregue`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus6`
  FOREIGN KEY (`id_osstatus$fechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
