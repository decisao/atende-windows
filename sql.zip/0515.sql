
ALTER TABLE `natureza` 
ADD COLUMN `nfemodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `consumidorfinal`,
ADD COLUMN `nfeserie` SMALLINT(6) NULL DEFAULT NULL AFTER `nfemodelo`,
ADD COLUMN `nfefinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `nfeserie`;

ALTER TABLE `empresa` 
ADD COLUMN `regime` SMALLINT(6) NULL DEFAULT NULL AFTER `pdfcaminho`;

