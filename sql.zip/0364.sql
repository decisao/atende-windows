
ALTER TABLE `transferenciaproduto` 
DROP FOREIGN KEY `fk_transferenciaproduto_local2`,
DROP FOREIGN KEY `fk_transferenciaproduto_empresa1`;

ALTER TABLE `transferencia` 
ADD COLUMN `id_empresa$destino` BIGINT(11) NOT NULL AFTER `id_usuario`,
ADD COLUMN `id_local$destino` BIGINT(11) NOT NULL AFTER `id_empresa$destino`,
ADD INDEX `fk_transferencia_empresa2_idx` (`id_empresa$destino` ASC),
ADD INDEX `fk_transferencia_local1_idx` (`id_local$destino` ASC);

ALTER TABLE `transferenciaproduto` 
DROP COLUMN `id_empresa`,
DROP COLUMN `id_localorigem`,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
DROP INDEX `fk_transferenciaproduto_local2_idx` ,
DROP INDEX `fk_transferenciaproduto_empresa1_idx` ;

ALTER TABLE `transferencia` 
ADD CONSTRAINT `fk_transferencia_empresa2`
  FOREIGN KEY (`id_empresa$destino`)
  REFERENCES `expresso`.`empresa` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_transferencia_local1`
  FOREIGN KEY (`id_local$destino`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;