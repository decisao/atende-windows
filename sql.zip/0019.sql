-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 20:54
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `limitecredito` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `proximanota`;

ALTER TABLE `expresso`.`contato` 
CHANGE COLUMN `restricao` `restricao` SMALLINT(1) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `limitecredito` `limitecredito` DECIMAL(10,2) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (19);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
