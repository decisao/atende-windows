-- MySQL Workbench Synchronization
-- Generated: 2016-09-05 13:10
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `propostacondicoes` VARCHAR(512) NULL DEFAULT NULL AFTER `limitecredito`,
ADD COLUMN `oshorarioatendimento` VARCHAR(60) NULL DEFAULT NULL AFTER `propostacondicoes`,
ADD COLUMN `id_natureza` BIGINT(11) NULL DEFAULT NULL AFTER `id_localvirtual`,
ADD INDEX `fk_empresa_natureza1_idx` (`id_natureza` ASC);

ALTER TABLE `expresso`.`compatibilidade` 
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_compatibilidade_marca1_idx` ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_natureza1`
  FOREIGN KEY (`id_natureza`)
  REFERENCES `expresso`.`natureza` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (39);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
