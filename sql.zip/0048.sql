-- MySQL Workbench Synchronization
-- Generated: 2016-11-07 18:42
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER SCHEMA `expresso`  DEFAULT CHARACTER SET utf8  DEFAULT COLLATE utf8_general_ci ;

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE `expresso`.`local` 
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`atualizacao` 
ADD COLUMN `ok` SMALLINT(6) NOT NULL DEFAULT 1 AFTER `data`;

ALTER TABLE `expresso`.`recursousuario` 
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

ALTER TABLE `expresso`.`navlogs` 
ADD INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
ADD INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
DROP INDEX `fk_navlogs_recurso1_idx` ,
DROP INDEX `fk_navlogs_usuario1_idx` ;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
