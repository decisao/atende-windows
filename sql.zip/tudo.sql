INSERT INTO atualizacao (id) VALUES (1);INSERT INTO atualizacao (id) VALUES (2);INSERT INTO atualizacao (id) VALUES (3);INSERT INTO atualizacao (id) VALUES (4);INSERT INTO atualizacao (id) VALUES (5);INSERT INTO atualizacao (id) VALUES (6);INSERT INTO atualizacao (id) VALUES (7);INSERT INTO atualizacao (id) VALUES (8);INSERT INTO atualizacao (id) VALUES (9);-- MySQL Workbench Synchronization
-- Generated: 2016-08-26 20:48
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (10);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
INSERT INTO atualizacao (id) VALUES (11);INSERT INTO atualizacao (id) VALUES (12);INSERT INTO atualizacao (id) VALUES (13);INSERT INTO atualizacao (id) VALUES (14);-- MySQL Workbench Synchronization
-- Generated: 2016-08-27 22:12
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`produto` 
CHANGE COLUMN `peso` `peso` DECIMAL(10,3) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compra` 
ADD COLUMN `valorseguro` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorfrete`,
ADD COLUMN `valoroutros` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorseguro`,
ADD COLUMN `valoripi` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `desconto`,
ADD COLUMN `valorbaseicms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valoripi`,
ADD COLUMN `valoricms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorbaseicms`,
ADD COLUMN `valorbaseicmssub` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valoricms`,
ADD COLUMN `valoricmssub` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorbaseicmssub`,
ADD COLUMN `tracpfcnpj` VARCHAR(20) NULL DEFAULT NULL AFTER `status`,
ADD COLUMN `tranome` VARCHAR(60) NULL DEFAULT NULL AFTER `tracpfcnpj`,
ADD COLUMN `trainscestadual` VARCHAR(20) NULL DEFAULT NULL AFTER `tranome`,
ADD COLUMN `trafrete` SMALLINT(1) NULL DEFAULT NULL AFTER `trainscestadual`,
ADD COLUMN `tracodantt` VARCHAR(20) NULL DEFAULT NULL AFTER `trafrete`,
ADD COLUMN `traplaca` VARCHAR(10) NULL DEFAULT NULL AFTER `tracodantt`,
ADD COLUMN `traplacauf` CHAR(2) NULL DEFAULT NULL AFTER `traplaca`,
ADD COLUMN `tralogradouro` VARCHAR(60) NULL DEFAULT NULL AFTER `traplacauf`,
ADD COLUMN `tranumero` VARCHAR(10) NULL DEFAULT NULL AFTER `tralogradouro`,
ADD COLUMN `tracomplemento` VARCHAR(60) NULL DEFAULT NULL AFTER `tranumero`,
ADD COLUMN `trabairro` VARCHAR(60) NULL DEFAULT NULL AFTER `tracomplemento`,
ADD COLUMN `tracidade` VARCHAR(60) NULL DEFAULT NULL AFTER `trabairro`,
ADD COLUMN `trauf` CHAR(2) NULL DEFAULT NULL AFTER `tracidade`,
ADD COLUMN `tracep` VARCHAR(10) NULL DEFAULT NULL AFTER `trauf`,
ADD COLUMN `traquant` SMALLINT(1) NULL DEFAULT NULL AFTER `tracep`,
ADD COLUMN `traespecie` VARCHAR(10) NULL DEFAULT NULL AFTER `traquant`,
ADD COLUMN `tramarca` VARCHAR(20) NULL DEFAULT NULL AFTER `traespecie`,
ADD COLUMN `tranumeracao` VARCHAR(20) NULL DEFAULT NULL AFTER `tramarca`,
ADD COLUMN `trapesobruto` DECIMAL(10,3) NULL DEFAULT NULL AFTER `tranumeracao`,
ADD COLUMN `trapesoliquidol` DECIMAL(10,3) NULL DEFAULT NULL AFTER `trapesobruto`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `ncm` VARCHAR(10) NULL DEFAULT NULL AFTER `total`,
ADD COLUMN `cest` VARCHAR(10) NULL DEFAULT NULL AFTER `ncm`,
ADD COLUMN `cst` VARCHAR(10) NULL DEFAULT NULL AFTER `cest`,
ADD COLUMN `csosn` VARCHAR(10) NULL DEFAULT NULL AFTER `cst`,
ADD COLUMN `valorbaseicms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `csosn`,
ADD COLUMN `valoricms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorbaseicms`,
ADD COLUMN `valoripi` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valoricms`,
ADD COLUMN `valoraliqicms` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoripi`,
ADD COLUMN `valoraliqipi` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoraliqicms`,
ADD COLUMN `peso` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoraliqipi`;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `valorbaseicms` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valorcusto`,
ADD COLUMN `valoricms` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valorbaseicms`,
ADD COLUMN `valorbaseicmssub` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valoricms`,
ADD COLUMN `valoricmssub` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valorbaseicmssub`,
ADD COLUMN `valorfrete` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valoricmssub`,
ADD COLUMN `valorseguro` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valorfrete`,
ADD COLUMN `valoroutros` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valorseguro`,
ADD COLUMN `valoripi` DECIMAL(10,2) NULL DEFAULT NULL AFTER `valoroutros`,
ADD COLUMN `tracpfcnpj` VARCHAR(20) NULL DEFAULT NULL AFTER `notadataemissao`,
ADD COLUMN `tranome` VARCHAR(60) NULL DEFAULT NULL AFTER `tracpfcnpj`,
ADD COLUMN `trainscestadual` VARCHAR(20) NULL DEFAULT NULL AFTER `tranome`,
ADD COLUMN `trafrete` SMALLINT(1) NULL DEFAULT NULL AFTER `trainscestadual`,
ADD COLUMN `tracodantt` VARCHAR(20) NULL DEFAULT NULL AFTER `trafrete`,
ADD COLUMN `traplaca` VARCHAR(10) NULL DEFAULT NULL AFTER `tracodantt`,
ADD COLUMN `traplacauf` CHAR(2) NULL DEFAULT NULL AFTER `traplaca`,
ADD COLUMN `tralogradouro` VARCHAR(60) NULL DEFAULT NULL AFTER `traplacauf`,
ADD COLUMN `tranumero` VARCHAR(10) NULL DEFAULT NULL AFTER `tralogradouro`,
ADD COLUMN `tracomplemento` VARCHAR(60) NULL DEFAULT NULL AFTER `tranumero`,
ADD COLUMN `trabairro` VARCHAR(60) NULL DEFAULT NULL AFTER `tracomplemento`,
ADD COLUMN `tracidade` VARCHAR(60) NULL DEFAULT NULL AFTER `trabairro`,
ADD COLUMN `trauf` CHAR(2) NULL DEFAULT NULL AFTER `tracidade`,
ADD COLUMN `tracep` VARCHAR(10) NULL DEFAULT NULL AFTER `trauf`,
ADD COLUMN `traquant` SMALLINT(1) NULL DEFAULT NULL AFTER `tracep`,
ADD COLUMN `traespecie` VARCHAR(20) NULL DEFAULT NULL AFTER `traquant`,
ADD COLUMN `tramarca` VARCHAR(20) NULL DEFAULT NULL AFTER `traespecie`,
ADD COLUMN `tranumeracao` VARCHAR(20) NULL DEFAULT NULL AFTER `tramarca`,
ADD COLUMN `trapesobruto` DECIMAL(10,3) NULL DEFAULT NULL AFTER `tranumeracao`,
ADD COLUMN `trapesoliquido` DECIMAL(10,3) NULL DEFAULT NULL AFTER `trapesobruto`;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `ncm` VARCHAR(10) NULL DEFAULT NULL AFTER `total`,
ADD COLUMN `cest` VARCHAR(10) NULL DEFAULT NULL AFTER `ncm`,
ADD COLUMN `cst` VARCHAR(10) NULL DEFAULT NULL AFTER `cest`,
ADD COLUMN `csosn` VARCHAR(10) NULL DEFAULT NULL AFTER `cst`,
ADD COLUMN `valorbaseicms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `csosn`,
ADD COLUMN `valoricms` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorbaseicms`,
ADD COLUMN `valoripi` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valoricms`,
ADD COLUMN `valoraliqicms` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoripi`,
ADD COLUMN `valoraliqipi` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoraliqicms`,
ADD COLUMN `peso` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `valoraliqipi`;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (15);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 11:38
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`ncm` 
ADD COLUMN `federalnac` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `federalimp` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalnac`,
ADD COLUMN `estadual` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalimp`,
ADD COLUMN `municipal` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `estadual`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `contribuinte` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `trapesoliquido`,
ADD COLUMN `presencial` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `contribuinte`,
ADD COLUMN `consumidorfinal` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `presencial`;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

CREATE TABLE IF NOT EXISTS `expresso`.`natureza` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `compra` SMALLINT(1) NOT NULL DEFAULT 0,
  `venda` SMALLINT(1) NOT NULL DEFAULT 0,
  `estoque` SMALLINT(1) NOT NULL DEFAULT 0,
  `financeiro` SMALLINT(1) NOT NULL DEFAULT 0,
  `comissionado` SMALLINT(1) NOT NULL DEFAULT 0,
  `contribuinte` SMALLINT(1) NOT NULL DEFAULT 0,
  `presencial` SMALLINT(1) NOT NULL DEFAULT 0,
  `consumidorfinal` SMALLINT(1) NOT NULL DEFAULT 0,
  `excluido` SMALLINT(1) NOT NULL DEFAULT 0,
  `id_empresa` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
  CONSTRAINT `fk_natureza_empresa1`
    FOREIGN KEY (`id_empresa`)
    REFERENCES `expresso`.`empresa` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `expresso`.`regra` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `cst` VARCHAR(10) NOT NULL DEFAULT 0,
  `csosn` VARCHAR(10) NOT NULL DEFAULT 0,
  `cfop` VARCHAR(10) NOT NULL DEFAULT 0,
  `icms` SMALLINT(1) NOT NULL DEFAULT 0,
  `icmsaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `ipi` SMALLINT(1) NOT NULL DEFAULT 0,
  `ipialiq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `pis` SMALLINT(1) NOT NULL DEFAULT 0,
  `pisaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `cofins` SMALLINT(1) NOT NULL DEFAULT 0,
  `cofinsaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `issqn` SMALLINT(1) NOT NULL DEFAULT 0,
  `issqnaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `tiponota` VARCHAR(10) NOT NULL,
  `datainicio` DATE NOT NULL,
  `datafim` DATE NOT NULL,
  `sub` SMALLINT(1) NOT NULL DEFAULT 0,
  `difal` SMALLINT(1) NOT NULL DEFAULT 0,
  `icmsorigem` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `icmsdestino` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `icmspartilha` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `estadodentro` SMALLINT(1) NOT NULL DEFAULT 0,
  `estadofora` SMALLINT(1) NOT NULL DEFAULT 0,
  `estados` VARCHAR(512) NULL DEFAULT NULL,
  `excluido` SMALLINT(1) NOT NULL DEFAULT 0,
  `id_natureza` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
  CONSTRAINT `fk_regra_natureza1`
    FOREIGN KEY (`id_natureza`)
    REFERENCES `expresso`.`natureza` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

INSERT INTO atualizacao (id) VALUES (16);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 14:42
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `federalnac` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `cest`,
ADD COLUMN `federalimp` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalnac`,
ADD COLUMN `estadual` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalimp`,
ADD COLUMN `municipal` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `estadual`;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (17);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 19:00
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `certificadoserie` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualprincipal`,
ADD COLUMN `certificadosenha` VARCHAR(60) NULL DEFAULT NULL AFTER `certificadoserie`,
ADD COLUMN `proximanota` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `certificadosenha`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (18);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 20:54
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `limitecredito` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `proximanota`;

ALTER TABLE `expresso`.`contato` 
CHANGE COLUMN `restricao` `restricao` SMALLINT(1) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `limitecredito` `limitecredito` DECIMAL(10,2) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (19);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
INSERT INTO atualizacao (id) VALUES (20);-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 10:47
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compra` 
ADD COLUMN `id_natureza` BIGINT(11) NOT NULL AFTER `id_meio`,
ADD INDEX `fk_compra_natureza1_idx` (`id_natureza` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

ALTER TABLE `expresso`.`compra` 
ADD CONSTRAINT `fk_compra_natureza1`
  FOREIGN KEY (`id_natureza`)
  REFERENCES `expresso`.`natureza` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (21);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 12:31
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `cfop` VARCHAR(10) NULL DEFAULT NULL AFTER `ncm`;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (22);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 13:58
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `cfop` VARCHAR(10) NULL DEFAULT NULL AFTER `municipal`;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (23);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 14:02
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `id_natureza` BIGINT(11) NOT NULL AFTER `id_lancamento`,
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC);

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD CONSTRAINT `fk_vendaos_natureza1`
  FOREIGN KEY (`id_natureza`)
  REFERENCES `expresso`.`natureza` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 15:35
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantmax` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `peso`,
ADD COLUMN `id_local` BIGINT(11) NOT NULL AFTER `id_produto`,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC);

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
ADD CONSTRAINT `fk_vendaosproduto_local1`
  FOREIGN KEY (`id_local`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (24);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 15:40
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
CHANGE COLUMN `lojavirtual` `lojavirtual` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lojavirtualprincipal` `lojavirtualprincipal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `proximanota` `proximanota` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL ;

ALTER TABLE `expresso`.`usuario` 
CHANGE COLUMN `licenca` `licenca` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`cargo` 
CHANGE COLUMN `tecnico` `tecnico` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `vendedor` `vendedor` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `trocaempresa` `trocaempresa` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `custo` `custo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco1` `preco1` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco2` `preco2` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco3` `preco3` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco4` `preco4` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco5` `preco5` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`cidade` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`logradouro` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`logs` 
CHANGE COLUMN `upload` `upload` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`recurso` 
CHANGE COLUMN `tipo` `tipo` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`privilegio` 
CHANGE COLUMN `tipo` `tipo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `visivel` `visivel` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `novo` `novo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `editar` `editar` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluir` `excluir` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `imprimir` `imprimir` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `exportar` `exportar` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `logs` `logs` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lixeira` `lixeira` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `fechamento` `fechamento` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`contato` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `restricao` `restricao` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`categoria` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`servico` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`produto` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`marca` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`modelo` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`estoque` 
CHANGE COLUMN `minimo` `minimo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lojavirtual` `lojavirtual` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`local` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`fisico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`proposta` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`propostaservico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`propostaproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compra` 
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `fechado` `fechado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `trafrete` `trafrete` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `traquant` `traquant` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
CHANGE COLUMN `prioridade` `prioridade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `autorizado` `autorizado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `entregue` `entregue` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `fechado` `fechado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `trafrete` `trafrete` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `traquant` `traquant` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contribuinte` `contribuinte` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `presencial` `presencial` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `consumidorfinal` `consumidorfinal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ,
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `quantmax` `quantmax` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC),
DROP INDEX `fk_vendaosproduto_local1_idx` ;

ALTER TABLE `expresso`.`vendaosservico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`vendaostecnico` 
CHANGE COLUMN `participacao` `participacao` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`ostipo` 
CHANGE COLUMN `prazo` `prazo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osstatus` 
CHANGE COLUMN `interno` `interno` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`oslocal` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osocorrencia` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osoperadora` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`transferencia` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`pagar` 
CHANGE COLUMN `item` `item` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`receber` 
CHANGE COLUMN `item` `item` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `boletoenviado` `boletoenviado` SMALLINT(6) NULL DEFAULT 0 ,
CHANGE COLUMN `boletobaixado` `boletobaixado` SMALLINT(6) NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`plano` 
CHANGE COLUMN `disponivel` `disponivel` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`conta` 
CHANGE COLUMN `banco` `banco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `agencia` `agencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `agenciadv` `agenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `conta` `conta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contadv` `contadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `carteira` `carteira` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `variacao` `variacao` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contrato` `contrato` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `protesto` `protesto` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `remessa` `remessa` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `aceite` `aceite` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`meio` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`lancamento` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`lancamentoplano` 
CHANGE COLUMN `automatico` `automatico` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `porcentagem` `porcentagem` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `tipolan` `tipolan` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`movimento` 
CHANGE COLUMN `tipolan` `tipolan` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`condicao` 
CHANGE COLUMN `diafixo` `diafixo` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`recebimentoitem` 
CHANGE COLUMN `chequebanco` `chequebanco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagencia` `chequeagencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagenciadv` `chequeagenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeconta` `chequeconta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequecontadv` `chequecontadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequenumero` `chequenumero` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`pagamentoitem` 
CHANGE COLUMN `chequebanco` `chequebanco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagencia` `chequeagencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagenciadv` `chequeagenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeconta` `chequeconta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequecontadv` `chequecontadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequenumero` `chequenumero` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`natureza` 
CHANGE COLUMN `compra` `compra` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `venda` `venda` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estoque` `estoque` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `financeiro` `financeiro` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `contribuinte` `contribuinte` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `presencial` `presencial` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `consumidorfinal` `consumidorfinal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`regra` 
CHANGE COLUMN `icms` `icms` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `ipi` `ipi` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `pis` `pis` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `cofins` `cofins` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `issqn` `issqn` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `sub` `sub` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `difal` `difal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estadodentro` `estadodentro` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estadofora` `estadofora` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

INSERT INTO atualizacao (id) VALUES (26);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 14:43
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC),
DROP INDEX `fk_vendaosproduto_local1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD COLUMN `id_condicao` BIGINT(11) NULL DEFAULT NULL AFTER `id_empresa`,
ADD COLUMN `id_lancamento` BIGINT(11) NULL DEFAULT NULL AFTER `id_condicao`,
ADD COLUMN `id_meio` BIGINT(11) NULL DEFAULT NULL AFTER `id_lancamento`,
ADD INDEX `fk_natureza_condicao1_idx` (`id_condicao` ASC),
ADD INDEX `fk_natureza_lancamento1_idx` (`id_lancamento` ASC),
ADD INDEX `fk_natureza_meio1_idx` (`id_meio` ASC);

ALTER TABLE `expresso`.`natureza` 
ADD CONSTRAINT `fk_natureza_condicao1`
  FOREIGN KEY (`id_condicao`)
  REFERENCES `expresso`.`condicao` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_natureza_lancamento1`
  FOREIGN KEY (`id_lancamento`)
  REFERENCES `expresso`.`lancamento` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_natureza_meio1`
  FOREIGN KEY (`id_meio`)
  REFERENCES `expresso`.`meio` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (27);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 15:50
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compra` 
ADD COLUMN `id_lancamento` BIGINT(11) NOT NULL AFTER `id_natureza`,
ADD INDEX `fk_compra_lancamento1_idx` (`id_lancamento` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC),
DROP INDEX `fk_vendaosproduto_local1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_condicao1_idx` (`id_condicao` ASC),
ADD INDEX `fk_natureza_lancamento1_idx` (`id_lancamento` ASC),
ADD INDEX `fk_natureza_meio1_idx` (`id_meio` ASC),
DROP INDEX `fk_natureza_meio1_idx` ,
DROP INDEX `fk_natureza_lancamento1_idx` ,
DROP INDEX `fk_natureza_condicao1_idx` ;

ALTER TABLE `expresso`.`compra` 
ADD CONSTRAINT `fk_compra_lancamento1`
  FOREIGN KEY (`id_lancamento`)
  REFERENCES `expresso`.`lancamento` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (28);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 17:58
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `id_regra` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC);

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
ADD CONSTRAINT `fk_vendaosproduto_regra1`
  FOREIGN KEY (`id_regra`)
  REFERENCES `expresso`.`regra` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (29);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 22:26
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `id_marca` BIGINT(11) NULL DEFAULT NULL AFTER `id_osoperadora`,
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC);

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD CONSTRAINT `fk_vendaos_marca1`
  FOREIGN KEY (`id_marca`)
  REFERENCES `expresso`.`marca` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (30);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 22:40
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`modelo` 
CHANGE COLUMN `id` `id` BIGINT(11) NOT NULL AUTO_INCREMENT ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (31);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 23:18
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `os` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `id_natureza`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `os`),
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (32);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 23:22
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`),
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (33);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-08-31 01:06
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `certificadocaminho` VARCHAR(60) NULL DEFAULT NULL AFTER `certificadoserie`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (34);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-02 13:19
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`usuario` 
ADD UNIQUE INDEX `email_UNIQUE` (`email` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (35);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-02 14:52
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`produtoimagem` 
ADD COLUMN `imagem` LONGBLOB NOT NULL AFTER `nome`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (36);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-03 00:31
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compatibilidade` 
ADD COLUMN `id_marca` BIGINT(11) NOT NULL AFTER `id`,
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`compatibilidade` 
ADD CONSTRAINT `fk_compatibilidade_marca1`
  FOREIGN KEY (`id_marca`)
  REFERENCES `expresso`.`marca` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (37);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-03 01:10
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compatibilidade` 
ADD COLUMN `excluido` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `id_produto`,
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_compatibilidade_marca1_idx` ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (38);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-05 13:10
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `propostacondicoes` VARCHAR(512) NULL DEFAULT NULL AFTER `limitecredito`,
ADD COLUMN `oshorarioatendimento` VARCHAR(60) NULL DEFAULT NULL AFTER `propostacondicoes`,
ADD COLUMN `id_natureza` BIGINT(11) NULL DEFAULT NULL AFTER `id_localvirtual`,
ADD INDEX `fk_empresa_natureza1_idx` (`id_natureza` ASC);

ALTER TABLE `expresso`.`compatibilidade` 
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_compatibilidade_marca1_idx` ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_natureza1`
  FOREIGN KEY (`id_natureza`)
  REFERENCES `expresso`.`natureza` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (39);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-05 14:40
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD INDEX `fk_empresa_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_empresa_natureza1_idx` ;

ALTER TABLE `expresso`.`compatibilidade` 
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_compatibilidade_marca1_idx` ;

ALTER TABLE `expresso`.`proposta` 
ADD COLUMN `id_condicao` BIGINT(11) NULL DEFAULT NULL AFTER `id_usuario`,
ADD COLUMN `id_meio` BIGINT(11) NULL DEFAULT NULL AFTER `id_condicao`,
ADD INDEX `fk_proposta_condicao1_idx` (`id_condicao` ASC),
ADD INDEX `fk_proposta_meio1_idx` (`id_meio` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`proposta` 
ADD CONSTRAINT `fk_proposta_condicao1`
  FOREIGN KEY (`id_condicao`)
  REFERENCES `expresso`.`condicao` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_proposta_meio1`
  FOREIGN KEY (`id_meio`)
  REFERENCES `expresso`.`meio` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (40);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-09-19 17:29
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`produto` 
CHANGE COLUMN `partnumber` `partnumber` VARCHAR(254) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

INSERT INTO atualizacao (id) VALUES (41);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
INSERT INTO atualizacao (id) VALUES (42);INSERT INTO atualizacao (id) VALUES (43);INSERT INTO atualizacao (id) VALUES (44);-- MySQL Workbench Synchronization
-- Generated: 2016-10-12 10:39
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
CHANGE COLUMN `id_localvirtual` `id_local$virtual` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`local` 
CHANGE COLUMN `local` `nome` VARCHAR(60) NOT NULL ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (45);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-10-12 15:08
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE `expresso`.`local` 
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

CREATE TABLE IF NOT EXISTS `expresso`.`recursousuario` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `janelacheia` SMALLINT(6) NOT NULL DEFAULT 0,
  `selfiltro` VARCHAR(512) NULL DEFAULT NULL,
  `gradecampo` VARCHAR(512) NULL DEFAULT NULL,
  `impressaocampo` VARCHAR(512) NULL DEFAULT NULL,
  `impressaogrupo` VARCHAR(60) NULL DEFAULT NULL,
  `impressaopapel` VARCHAR(60) NULL DEFAULT NULL,
  `id_recurso` BIGINT(11) NOT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
  INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
  CONSTRAINT `fk_recursousuario_recurso1`
    FOREIGN KEY (`id_recurso`)
    REFERENCES `expresso`.`recurso` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_recursousuario_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `expresso`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (46);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-10-24 20:04
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE `expresso`.`local` 
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`recursousuario` 
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

CREATE TABLE IF NOT EXISTS `expresso`.`navlogs` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `idtabela` BIGINT(11) NULL DEFAULT NULL,
  `tipo` CHAR(1) NOT NULL,
  `datahora` DATETIME NOT NULL,
  `computador` VARCHAR(60) NOT NULL,
  `acao` VARCHAR(60) NOT NULL,
  `id_recurso` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
  INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
  CONSTRAINT `fk_navlogs_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `expresso`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_navlogs_recurso1`
    FOREIGN KEY (`id_recurso`)
    REFERENCES `expresso`.`recurso` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (47);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2016-11-07 18:42
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER SCHEMA `expresso`  DEFAULT CHARACTER SET utf8  DEFAULT COLLATE utf8_general_ci ;

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE `expresso`.`local` 
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`atualizacao` 
ADD COLUMN `ok` SMALLINT(6) NOT NULL DEFAULT 1 AFTER `data`;

ALTER TABLE `expresso`.`recursousuario` 
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

ALTER TABLE `expresso`.`navlogs` 
ADD INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
ADD INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
DROP INDEX `fk_navlogs_recurso1_idx` ,
DROP INDEX `fk_navlogs_usuario1_idx` ;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-03-25 14:43
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `compra` 
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`;

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `vendaos` 
CHANGE COLUMN `os` `os` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`,
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `transferencia` 
ADD COLUMN `fechado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `fechadopro` SMALLINT(6) NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-05-13 12:35
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa`
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE  `empresa`
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE  `local`
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE  `compra`
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`;

ALTER TABLE  `compraproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `vendaos`
CHANGE COLUMN `os` `os` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`,
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `vendaosproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `transferencia`
ADD COLUMN `fechado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `fechadopro` SMALLINT(6) NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `transferenciaproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `recursousuario`
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

ALTER TABLE  `navlogs`
ADD INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
ADD INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
DROP INDEX `fk_navlogs_recurso1_idx` ,
DROP INDEX `fk_navlogs_usuario1_idx` ;

CREATE TABLE IF NOT EXISTS  `cardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `valorunitario` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valorfrete` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valoroutros` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `impostos` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `data` DATETIME NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `cpfcnpj` VARCHAR(60) NULL DEFAULT NULL,
  `nome` VARCHAR(60) NOT NULL,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES  `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES  `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES  `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE  `empresa`
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES  `local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-08-20 23:12
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_condicao` BIGINT(11) NULL DEFAULT NULL AFTER `id_natureza`,
ADD INDEX `fk_empresa_condicao1_idx` (`id_condicao` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_condicao1`
  FOREIGN KEY (`id_condicao`)
  REFERENCES  `condicao` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-08-20 23:32
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_meio` BIGINT(11) NULL DEFAULT NULL AFTER `id_condicao`,
ADD INDEX `fk_empresa_meio1_idx` (`id_meio` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_meio1`
  FOREIGN KEY (`id_meio`)
  REFERENCES  `meio` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-09-07 11:32
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_osstatus$aberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$autorizada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$iniciada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$nautorizada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$entregue` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$fechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD INDEX `fk_empresa_osstatus1_idx` (`id_osstatus$aberta` ASC),
ADD INDEX `fk_empresa_osstatus2_idx` (`id_osstatus$autorizada` ASC),
ADD INDEX `fk_empresa_osstatus3_idx` (`id_osstatus$iniciada` ASC),
ADD INDEX `fk_empresa_osstatus4_idx` (`id_osstatus$nautorizada` ASC),
ADD INDEX `fk_empresa_osstatus5_idx` (`id_osstatus$entregue` ASC),
ADD INDEX `fk_empresa_osstatus6_idx` (`id_osstatus$fechada` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_osstatus1`
  FOREIGN KEY (`id_osstatus$aberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus2`
  FOREIGN KEY (`id_osstatus$autorizada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus3`
  FOREIGN KEY (`id_osstatus$iniciada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus4`
  FOREIGN KEY (`id_osstatus$nautorizada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus5`
  FOREIGN KEY (`id_osstatus$entregue`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus6`
  FOREIGN KEY (`id_osstatus$fechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-09-07 19:00
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_osstatus$vaberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$vfechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$caberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$cfechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD INDEX `fk_empresa_osstatus7_idx` (`id_osstatus$vaberta` ASC),
ADD INDEX `fk_empresa_osstatus8_idx` (`id_osstatus$vfechada` ASC),
ADD INDEX `fk_empresa_osstatus9_idx` (`id_osstatus$caberta` ASC),
ADD INDEX `fk_empresa_osstatus10_idx` (`id_osstatus$cfechada` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_osstatus7`
  FOREIGN KEY (`id_osstatus$vaberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus8`
  FOREIGN KEY (`id_osstatus$vfechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus9`
  FOREIGN KEY (`id_osstatus$caberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus10`
  FOREIGN KEY (`id_osstatus$cfechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-11-15 11:14
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `proposta` 
ADD COLUMN `margem` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorcusto`;

ALTER TABLE `propostaproduto` 
ADD COLUMN `margem` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `totalcusto`;

CREATE TABLE IF NOT EXISTS `cardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `valorunitario` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valorfrete` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valoroutros` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `impostos` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `data` DATETIME NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `cpfcnpj` VARCHAR(60) NULL DEFAULT NULL,
  `nome` VARCHAR(60) NOT NULL,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `empresa` ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus1`
  FOREIGN KEY (`id_osstatus$aberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus2`
  FOREIGN KEY (`id_osstatus$autorizada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus3`
  FOREIGN KEY (`id_osstatus$iniciada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus4`
  FOREIGN KEY (`id_osstatus$nautorizada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus5`
  FOREIGN KEY (`id_osstatus$entregue`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus6`
  FOREIGN KEY (`id_osstatus$fechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus7`
  FOREIGN KEY (`id_osstatus$vaberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus8`
  FOREIGN KEY (`id_osstatus$vfechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus9`
  FOREIGN KEY (`id_osstatus$caberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus10`
  FOREIGN KEY (`id_osstatus$cfechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-11-15 12:27
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `propostaproduto` 
ADD COLUMN `valororiginal` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorunitario`,
ADD COLUMN `descontoperc` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `desconto`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-11-15 14:20
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `empresa` 
ADD COLUMN `margemcustomedio` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `oshorarioatendimento`;

ALTER TABLE `propostaproduto` 
ADD COLUMN `preconum` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `nome`;

ALTER TABLE `propostaproduto` 
ADD COLUMN `estoque` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `preconum`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2017-11-18 20:18
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `proposta` 
ADD COLUMN `valorprodutooriginal` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorproduto`,
ADD COLUMN `descontoperc` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `desconto`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-02-17 23:36
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `empresa` 
ADD COLUMN `emailemissor` VARCHAR(60) NULL DEFAULT NULL AFTER `id_osstatus$aberta`,
ADD COLUMN `emailcopia` VARCHAR(60) NULL DEFAULT NULL AFTER `emailemissor`,
ADD COLUMN `emailsmtp` VARCHAR(60) NULL DEFAULT NULL AFTER `emailcopia`,
ADD COLUMN `emailporta` SMALLINT(6) NULL DEFAULT NULL AFTER `emailsmtp`,
ADD COLUMN `emailusuario` VARCHAR(60) NULL DEFAULT NULL AFTER `emailporta`,
ADD COLUMN `emailsenha` VARCHAR(60) NULL DEFAULT NULL AFTER `emailusuario`,
ADD COLUMN `emailssl` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `emailsenha`,
ADD COLUMN `emailtls` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `emailssl`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-02-20 23:23
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `recursousuario` 
ADD COLUMN `impressaosoma` VARCHAR(512) NULL DEFAULT NULL AFTER `impressaogrupo`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-02-21 22:17
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `compra` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-03-03 19:23
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `servico` 
ADD COLUMN `id_servicotipo` BIGINT(11) NULL DEFAULT NULL AFTER `excluido`,
ADD INDEX `fk_servico_servicotipo1_idx` (`id_servicotipo` ASC);

ALTER TABLE `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_regra`,
ADD INDEX `fk_vendaosproduto_usuario1_idx` (`id_usuario` ASC);

ALTER TABLE `vendaosservico` 
ADD COLUMN `percentualtecnico` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `total`,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_servico`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `id_usuario`),
ADD INDEX `fk_vendaosservico_usuario1_idx` (`id_usuario` ASC);

CREATE TABLE IF NOT EXISTS `servicotipo` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `percentual` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `excluido` SMALLINT(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `servico` 
ADD CONSTRAINT `fk_servico_servicotipo1`
  FOREIGN KEY (`id_servicotipo`)
  REFERENCES `servicotipo` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `vendaosproduto` 
ADD CONSTRAINT `fk_vendaosproduto_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `vendaosservico` 
ADD CONSTRAINT `fk_vendaosservico_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-03-03 19:56
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `empresa` 
ADD COLUMN `imglogo` LONGBLOB NULL DEFAULT NULL AFTER `emailtls`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-05-19 13:30
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `produtoimagem` 
ADD COLUMN `descricao` VARCHAR(60) NULL DEFAULT NULL AFTER `nome`,
ADD COLUMN `excluido` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `imagem`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-05-22 19:21
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE TABLE IF NOT EXISTS `arquivo` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `fisico` VARCHAR(60) NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `detalhes` VARCHAR(254) NULL DEFAULT NULL,
  `data` DATETIME NOT NULL,
  `conteudo` LONGBLOB NULL DEFAULT NULL,
  `idtabela` BIGINT(11) NOT NULL,
  `id_recurso` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_arquivo_recurso1_idx` (`id_recurso` ASC),
  CONSTRAINT `fk_arquivo_recurso1`
    FOREIGN KEY (`id_recurso`)
    REFERENCES `expresso`.`recurso` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-05-29 01:46
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `arquivo` 
ADD COLUMN `excluido` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `idtabela`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2018-05-29 18:13
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `arquivo` 
DROP COLUMN `conteudo`,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_recurso`,
ADD INDEX `fk_arquivo_usuario1_idx` (`id_usuario` ASC);

CREATE TABLE IF NOT EXISTS `arquivoconteudo` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `conteudo` LONGBLOB NULL DEFAULT NULL,
  `id_arquivo` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_arquivoconteudo_arquivo1_idx` (`id_arquivo` ASC),
  UNIQUE INDEX `id_arquivo_UNIQUE` (`id_arquivo` ASC),
  CONSTRAINT `fk_arquivoconteudo_arquivo1`
    FOREIGN KEY (`id_arquivo`)
    REFERENCES `expresso`.`arquivo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `arquivo` 
ADD CONSTRAINT `fk_arquivo_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `expresso`.`usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

ALTER TABLE `usuario`
	ADD UNIQUE INDEX `cpf_UNIQUE` (`cpf`);
ALTER TABLE `pagar` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `receber` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `vendaos` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `empresa` 
ADD COLUMN `certificadoa1` LONGBLOB NULL DEFAULT NULL AFTER `imglogo`;
ALTER TABLE `pagar` 
CHANGE COLUMN `id_pagamento` `id_pagamento` BIGINT(11) NULL DEFAULT NULL ,
ADD COLUMN `contato` VARCHAR(60) NULL DEFAULT NULL AFTER `id_pagamento`,
ADD COLUMN `email` VARCHAR(60) NULL DEFAULT NULL AFTER `contato`,
ADD COLUMN `fone` VARCHAR(20) NULL DEFAULT NULL AFTER `email`;

ALTER TABLE `receber` 
CHANGE COLUMN `id_recebimento` `id_recebimento` BIGINT(11) NULL DEFAULT NULL ,
ADD COLUMN `contato` VARCHAR(60) NULL DEFAULT NULL AFTER `id_recebimento`,
ADD COLUMN `email` VARCHAR(60) NULL DEFAULT NULL AFTER `contato`,
ADD COLUMN `fone` VARCHAR(20) NULL DEFAULT NULL AFTER `email`;

ALTER TABLE `transferenciaproduto` 
DROP FOREIGN KEY `fk_transferenciaproduto_local2`,
DROP FOREIGN KEY `fk_transferenciaproduto_empresa1`;

ALTER TABLE `transferencia` 
ADD COLUMN `id_empresa$destino` BIGINT(11) NOT NULL AFTER `id_usuario`,
ADD COLUMN `id_local$destino` BIGINT(11) NOT NULL AFTER `id_empresa$destino`,
ADD INDEX `fk_transferencia_empresa2_idx` (`id_empresa$destino` ASC),
ADD INDEX `fk_transferencia_local1_idx` (`id_local$destino` ASC);

ALTER TABLE `transferenciaproduto` 
DROP COLUMN `id_empresa`,
DROP COLUMN `id_localorigem`,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
DROP INDEX `fk_transferenciaproduto_local2_idx` ,
DROP INDEX `fk_transferenciaproduto_empresa1_idx` ;

ALTER TABLE `transferencia` 
ADD CONSTRAINT `fk_transferencia_empresa2`
  FOREIGN KEY (`id_empresa$destino`)
  REFERENCES `expresso`.`empresa` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_transferencia_local1`
  FOREIGN KEY (`id_local$destino`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
ALTER TABLE `transferenciaproduto` 
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`,
ADD COLUMN `codbarra` VARCHAR(13) NOT NULL AFTER `nome`,
ADD COLUMN `unidade` CHAR(2) NOT NULL AFTER `codbarra`;
ALTER TABLE `pagar`
	ALTER `id_compra` DROP DEFAULT;
ALTER TABLE `pagar`
	CHANGE COLUMN `id_compra` `id_compra` BIGINT(11) NULL AFTER `id_usuario`;
-- MySQL Workbench Synchronization
-- Generated: 2018-12-31 22:00
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `compra` 
ADD COLUMN `estoque` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`,
ADD COLUMN `financeiro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estoque`,
CHANGE COLUMN `fechado` `fechado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `financeiro`;

ALTER TABLE `vendaos` 
ADD COLUMN `estoque` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquido`,
ADD COLUMN `financeiro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estoque`,
CHANGE COLUMN `id_lancamento` `id_lancamento` BIGINT(11) NULL DEFAULT NULL ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2019-01-01 20:41
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `cargo` 
ADD COLUMN `reabertura` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `preco5`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2019-01-03 17:06
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `compraproduto` 
ADD COLUMN `custoultimo` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valoraliqipi`,
ADD COLUMN `customedio` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `custoultimo`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- MySQL Workbench Synchronization
-- Generated: 2019-01-04 23:02
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `cardex` 
DROP COLUMN `cpfcnpj`,
DROP COLUMN `impostos`,
DROP COLUMN `valoroutros`,
DROP COLUMN `valorfrete`,
ADD COLUMN `estoque` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `customedio`,
ADD COLUMN `id_produto` BIGINT(11) NOT NULL AFTER `id_usuario`,
CHANGE COLUMN `nome` `nome` VARCHAR(60) NOT NULL AFTER `id`,
CHANGE COLUMN `tipo` `tipo` VARCHAR(20) NOT NULL AFTER `nome`,
CHANGE COLUMN `data` `data` DATETIME NOT NULL AFTER `tipo`,
CHANGE COLUMN `valorunitario` `customedio` DECIMAL(10,2) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `total` `saldo` DECIMAL(10,2) NOT NULL DEFAULT 0 ,
ADD INDEX `fk_kardex_produto1_idx` (`id_produto` ASC);

RENAME TABLE `cardex` TO `kardex` ;

ALTER TABLE `compra` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`;

ALTER TABLE `vendaos` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`;

ALTER TABLE `privilegio` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechamento`;

ALTER TABLE `kardex` 
ADD CONSTRAINT `fk_kardex_produto1`
  FOREIGN KEY (`id_produto`)
  REFERENCES `produto` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

ALTER TABLE `kardex` 
 ADD COLUMN `serie` VARCHAR(60) NOT NULL DEFAULT "*" AFTER `quantidade`;
ALTER TABLE `vendaos` 
ADD COLUMN `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`;
DROP TABLE IF EXISTS `kardex` ;

CREATE TABLE IF NOT EXISTS `kardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `tipo` VARCHAR(20) NOT NULL,
  `data` DATETIME NOT NULL,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `serie` VARCHAR(60) NOT NULL DEFAULT "*",
  `customedio` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `estoque` SMALLINT(6) NOT NULL DEFAULT 0,
  `saldo` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  `id_produto` BIGINT(11) NOT NULL,
  `id_empresa` BIGINT(11) NOT NULL,
  `id_local` BIGINT(11) NOT NULL,
  `id_transferencia` BIGINT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  INDEX `fk_kardex_produto1_idx` (`id_produto` ASC),
  INDEX `fk_kardex_empresa1_idx` (`id_empresa` ASC),
  INDEX `fk_kardex_local1_idx` (`id_local` ASC),
  INDEX `fk_kardex_transferencia1_idx` (`id_transferencia` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_produto1`
    FOREIGN KEY (`id_produto`)
    REFERENCES `produto` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_empresa1`
    FOREIGN KEY (`id_empresa`)
    REFERENCES `empresa` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_local1`
    FOREIGN KEY (`id_local`)
    REFERENCES `local` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_transferencia1`
    FOREIGN KEY (`id_transferencia`)
    REFERENCES `transferencia` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;
ALTER TABLE `compra` 
ADD COLUMN `rateiofretecusto` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`,
ADD COLUMN `rateiooutroscusto` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `rateiofretecusto`;

ALTER TABLE `cargo` 
ADD COLUMN `estoquenegativo` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `reabertura`,
ADD COLUMN `financeiroabaixo` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estoquenegativo`,
ADD COLUMN `idclone` BIGINT(11) NULL DEFAULT NULL AFTER `financeiroabaixo`;

ALTER TABLE `transferencia` 
ADD COLUMN `recebido` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `recebidopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `recebido`,
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `recebidopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`,
ADD COLUMN `status` VARCHAR(60) NULL DEFAULT NULL AFTER `estornopro`;

ALTER TABLE `empresa` 
ADD COLUMN `lojavirtualtipo` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualprincipal`,
ADD COLUMN `lojavirtualusuario` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualtipo`,
ADD COLUMN `lojavirtualsenha` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualusuario`,
ADD COLUMN `lojavirtualchave` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualsenha`,
ADD COLUMN `contratoservico` LONGBLOB NULL DEFAULT NULL AFTER `certificadoa1`,
ADD COLUMN `contratoentradaos` LONGBLOB NULL DEFAULT NULL AFTER `contratoservico`,
ADD COLUMN `contratosaidaos` LONGBLOB NULL DEFAULT NULL AFTER `contratoentradaos`,
ADD COLUMN `contratochecklistos` LONGBLOB NULL DEFAULT NULL AFTER `contratosaidaos`,
ADD COLUMN `contratovenda` LONGBLOB NULL DEFAULT NULL AFTER `contratochecklistos`,
ADD COLUMN `contratoproposta` LONGBLOB NULL DEFAULT NULL AFTER `contratovenda`,
ADD COLUMN `nfetipo` VARCHAR(20) NULL DEFAULT NULL AFTER `contratoproposta`,
ADD COLUMN `xmlcaminho` VARCHAR(60) NULL DEFAULT NULL AFTER `nfetipo`,
ADD COLUMN `pdfcaminho` VARCHAR(60) NULL DEFAULT NULL AFTER `xmlcaminho`;
ALTER TABLE `cargo` 
ADD COLUMN `caixapdv` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `financeiroabaixo`;
ALTER TABLE `produto` 
ADD COLUMN `materiaprima` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `comissionado`,
ADD COLUMN `id_arquivo` BIGINT(11) NULL DEFAULT NULL AFTER `id_servico`,
ADD INDEX `fk_produto_arquivo1_idx` (`id_arquivo` ASC);
;

ALTER TABLE `produto` 
ADD CONSTRAINT `fk_produto_arquivo1`
  FOREIGN KEY (`id_arquivo`)
  REFERENCES `expresso`.`arquivo` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
ALTER TABLE `atualizacao` 
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `data`);
;
ALTER TABLE `vendaos` 
ADD COLUMN `id_local` BIGINT(11) NOT NULL AFTER `id_natureza`,
ADD INDEX `fk_vendaos_local1_idx` (`id_local` ASC);
;

ALTER TABLE `vendaos` 
ADD CONSTRAINT `fk_vendaos_local1`
  FOREIGN KEY (`id_local`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
ALTER TABLE `natureza` 
ADD COLUMN `nfemodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `consumidorfinal`,
ADD COLUMN `nfeserie` SMALLINT(6) NULL DEFAULT NULL AFTER `nfemodelo`,
ADD COLUMN `nfefinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `nfeserie`;

ALTER TABLE `empresa` 
ADD COLUMN `regime` SMALLINT(6) NULL DEFAULT NULL AFTER `pdfcaminho`;


ALTER TABLE `natureza` 
CHANGE COLUMN `nfeserie` `nfeserie` VARCHAR(20) NULL DEFAULT NULL ;

ALTER TABLE `vendaos` 
ADD COLUMN `notamodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `notadataemissao`;
ALTER TABLE `compra` 
ADD COLUMN `notamodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `notadataemissao`,
ADD COLUMN `notafinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `notamodelo`;

ALTER TABLE `vendaos` 
ADD COLUMN `notafinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `notamodelo`;
