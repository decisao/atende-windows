-- MySQL Workbench Synchronization
-- Generated: 2016-10-24 20:04
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE `expresso`.`empresa` 
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE `expresso`.`local` 
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`recursousuario` 
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

CREATE TABLE IF NOT EXISTS `expresso`.`navlogs` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `idtabela` BIGINT(11) NULL DEFAULT NULL,
  `tipo` CHAR(1) NOT NULL,
  `datahora` DATETIME NOT NULL,
  `computador` VARCHAR(60) NOT NULL,
  `acao` VARCHAR(60) NOT NULL,
  `id_recurso` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
  INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
  CONSTRAINT `fk_navlogs_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `expresso`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_navlogs_recurso1`
    FOREIGN KEY (`id_recurso`)
    REFERENCES `expresso`.`recurso` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `expresso`.`empresa` 
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `expresso`.`local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (47);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
