SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER SCHEMA `atende`  DEFAULT CHARACTER SET utf8  DEFAULT COLLATE utf8_general_ci ;

ALTER TABLE `atende`.`empresa` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`usuario` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`cargo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`cidade` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`logradouro` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`logs` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`recurso` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`privilegio` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`ncm` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`contato` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`categoria` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`servico` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`produto` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`marca` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`modelo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`compatibilidade` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`estoque` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`local` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`fisico` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`produtoimagem` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`proposta` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`propostaservico` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`propostaproduto` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`compra` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`compraproduto` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `atende`.`vendaosproduto` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `atende`.`vendaosservico` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`vendaostecnico` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`ostipo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`osstatus` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`vendaoscontato` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`oslocal` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`osocorrencia` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`osoperadora` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`transferencia` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`transferenciaproduto` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `atende`.`pagar` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`receber` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
CHANGE COLUMN `id_vendaos` `id_vendaos` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `atende`.`plano` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`conta` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`meio` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`lancamento` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`lancamentoplano` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`movimento` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`condicao` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`recebimento` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`recebimentoitem` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`pagamento` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`pagamentoitem` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`atualizacao` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`natureza` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`regra` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`recursousuario` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`navlogs` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`kardex` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `atende`.`servicotipo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`arquivo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`arquivoconteudo` 
CHARACTER SET = utf8 , COLLATE = utf8_general_ci ;

ALTER TABLE `atende`.`receber` 
DROP FOREIGN KEY `fk_receber_vendaos1`;

ALTER TABLE `atende`.`receber` ADD CONSTRAINT `fk_receber_vendaos1`
  FOREIGN KEY (`id_vendaos`)
  REFERENCES `atende`.`vendaos` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
