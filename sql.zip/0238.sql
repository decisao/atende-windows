-- MySQL Workbench Synchronization
-- Generated: 2017-09-07 19:00
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa` 
ADD COLUMN `id_osstatus$vaberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$vfechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$caberta` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD COLUMN `id_osstatus$cfechada` BIGINT(11) NULL DEFAULT NULL AFTER `id_meio`,
ADD INDEX `fk_empresa_osstatus7_idx` (`id_osstatus$vaberta` ASC),
ADD INDEX `fk_empresa_osstatus8_idx` (`id_osstatus$vfechada` ASC),
ADD INDEX `fk_empresa_osstatus9_idx` (`id_osstatus$caberta` ASC),
ADD INDEX `fk_empresa_osstatus10_idx` (`id_osstatus$cfechada` ASC);

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE  `empresa` 
ADD CONSTRAINT `fk_empresa_osstatus7`
  FOREIGN KEY (`id_osstatus$vaberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus8`
  FOREIGN KEY (`id_osstatus$vfechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus9`
  FOREIGN KEY (`id_osstatus$caberta`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus10`
  FOREIGN KEY (`id_osstatus$cfechada`)
  REFERENCES  `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
