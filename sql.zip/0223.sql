-- MySQL Workbench Synchronization
-- Generated: 2017-03-25 14:43
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `compra` 
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`;

ALTER TABLE  `compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `vendaos` 
CHANGE COLUMN `os` `os` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`,
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `transferencia` 
ADD COLUMN `fechado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `fechadopro` SMALLINT(6) NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
