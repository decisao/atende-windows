-- MySQL Workbench Synchronization
-- Generated: 2017-05-13 12:35
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE  `empresa`
DROP FOREIGN KEY `fk_empresa_local2`;

ALTER TABLE  `empresa`
DROP COLUMN `id_local$virtual`,
ADD COLUMN `id_local$virtual` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
DROP INDEX `fk_empresa_local2_idx` ,
ADD INDEX `fk_empresa_local2_idx` (`id_local$virtual` ASC);

ALTER TABLE  `local`
DROP COLUMN `nome`,
ADD COLUMN `nome` VARCHAR(60) NOT NULL AFTER `id`;

ALTER TABLE  `compra`
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `trapesoliquidol`;

ALTER TABLE  `compraproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `vendaos`
CHANGE COLUMN `os` `os` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`,
ADD COLUMN `fechadopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `vendaosproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `transferencia`
ADD COLUMN `fechado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `fechadopro` SMALLINT(6) NULL DEFAULT 0 AFTER `fechado`;

ALTER TABLE  `transferenciaproduto`
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `quantidadepro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `quantidade`;

ALTER TABLE  `recursousuario`
ADD INDEX `fk_recursousuario_recurso1_idx` (`id_recurso` ASC),
ADD INDEX `fk_recursousuario_usuario1_idx` (`id_usuario` ASC),
DROP INDEX `fk_recursousuario_usuario1_idx` ,
DROP INDEX `fk_recursousuario_recurso1_idx` ;

ALTER TABLE  `navlogs`
ADD INDEX `fk_navlogs_usuario1_idx` (`id_usuario` ASC),
ADD INDEX `fk_navlogs_recurso1_idx` (`id_recurso` ASC),
DROP INDEX `fk_navlogs_recurso1_idx` ,
DROP INDEX `fk_navlogs_usuario1_idx` ;

CREATE TABLE IF NOT EXISTS  `cardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `valorunitario` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valorfrete` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valoroutros` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `impostos` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `data` DATETIME NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `cpfcnpj` VARCHAR(60) NULL DEFAULT NULL,
  `nome` VARCHAR(60) NOT NULL,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES  `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES  `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES  `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE  `empresa`
ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES  `local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
