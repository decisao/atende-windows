-- MySQL Workbench Synchronization
-- Generated: 2018-05-29 18:13
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `arquivo` 
DROP COLUMN `conteudo`,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_recurso`,
ADD INDEX `fk_arquivo_usuario1_idx` (`id_usuario` ASC);

CREATE TABLE IF NOT EXISTS `arquivoconteudo` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `conteudo` LONGBLOB NULL DEFAULT NULL,
  `id_arquivo` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_arquivoconteudo_arquivo1_idx` (`id_arquivo` ASC),
  UNIQUE INDEX `id_arquivo_UNIQUE` (`id_arquivo` ASC),
  CONSTRAINT `fk_arquivoconteudo_arquivo1`
    FOREIGN KEY (`id_arquivo`)
    REFERENCES `expresso`.`arquivo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `arquivo` 
ADD CONSTRAINT `fk_arquivo_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `expresso`.`usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
