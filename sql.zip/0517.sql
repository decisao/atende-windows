
ALTER TABLE `compra` 
ADD COLUMN `notamodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `notadataemissao`,
ADD COLUMN `notafinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `notamodelo`;

ALTER TABLE `vendaos` 
ADD COLUMN `notafinalidade` SMALLINT(6) NULL DEFAULT NULL AFTER `notamodelo`;
