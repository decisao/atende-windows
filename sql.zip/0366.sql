
ALTER TABLE `pagar`
	ALTER `id_compra` DROP DEFAULT;
ALTER TABLE `pagar`
	CHANGE COLUMN `id_compra` `id_compra` BIGINT(11) NULL AFTER `id_usuario`;
