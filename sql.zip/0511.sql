
ALTER TABLE `cargo` 
ADD COLUMN `caixapdv` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `financeiroabaixo`;