
ALTER TABLE `produto` 
ADD COLUMN `materiaprima` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `comissionado`,
ADD COLUMN `id_arquivo` BIGINT(11) NULL DEFAULT NULL AFTER `id_servico`,
ADD INDEX `fk_produto_arquivo1_idx` (`id_arquivo` ASC);
;

ALTER TABLE `produto` 
ADD CONSTRAINT `fk_produto_arquivo1`
  FOREIGN KEY (`id_arquivo`)
  REFERENCES `expresso`.`arquivo` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;