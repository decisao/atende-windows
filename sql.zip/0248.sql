-- MySQL Workbench Synchronization
-- Generated: 2017-11-15 11:14
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `proposta` 
ADD COLUMN `margem` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `valorcusto`;

ALTER TABLE `propostaproduto` 
ADD COLUMN `margem` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `totalcusto`;

CREATE TABLE IF NOT EXISTS `cardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `valorunitario` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valorfrete` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `valoroutros` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `impostos` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `total` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `data` DATETIME NOT NULL,
  `tipo` VARCHAR(10) NOT NULL,
  `cpfcnpj` VARCHAR(60) NULL DEFAULT NULL,
  `nome` VARCHAR(60) NOT NULL,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `empresa` ADD CONSTRAINT `fk_empresa_local2`
  FOREIGN KEY (`id_local$virtual`)
  REFERENCES `local` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus1`
  FOREIGN KEY (`id_osstatus$aberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus2`
  FOREIGN KEY (`id_osstatus$autorizada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus3`
  FOREIGN KEY (`id_osstatus$iniciada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus4`
  FOREIGN KEY (`id_osstatus$nautorizada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus5`
  FOREIGN KEY (`id_osstatus$entregue`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus6`
  FOREIGN KEY (`id_osstatus$fechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus7`
  FOREIGN KEY (`id_osstatus$vaberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus8`
  FOREIGN KEY (`id_osstatus$vfechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus9`
  FOREIGN KEY (`id_osstatus$caberta`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_empresa_osstatus10`
  FOREIGN KEY (`id_osstatus$cfechada`)
  REFERENCES `osstatus` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
