
ALTER TABLE `natureza` 
CHANGE COLUMN `nfeserie` `nfeserie` VARCHAR(20) NULL DEFAULT NULL ;

ALTER TABLE `vendaos` 
ADD COLUMN `notamodelo` SMALLINT(6) NULL DEFAULT NULL AFTER `notadataemissao`;