
DROP TABLE IF EXISTS `kardex` ;

CREATE TABLE IF NOT EXISTS `kardex` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `tipo` VARCHAR(20) NOT NULL,
  `data` DATETIME NOT NULL,
  `quantidade` SMALLINT(6) NOT NULL DEFAULT 0,
  `serie` VARCHAR(60) NOT NULL DEFAULT "*",
  `customedio` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `estoque` SMALLINT(6) NOT NULL DEFAULT 0,
  `saldo` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `id_compra` BIGINT(11) NULL DEFAULT NULL,
  `id_vendaos` BIGINT(11) NULL DEFAULT NULL,
  `id_usuario` BIGINT(11) NOT NULL,
  `id_produto` BIGINT(11) NOT NULL,
  `id_empresa` BIGINT(11) NOT NULL,
  `id_local` BIGINT(11) NOT NULL,
  `id_transferencia` BIGINT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_cardex_compra1_idx` (`id_compra` ASC),
  INDEX `fk_cardex_vendaos1_idx` (`id_vendaos` ASC),
  INDEX `fk_cardex_usuario1_idx` (`id_usuario` ASC),
  INDEX `fk_kardex_produto1_idx` (`id_produto` ASC),
  INDEX `fk_kardex_empresa1_idx` (`id_empresa` ASC),
  INDEX `fk_kardex_local1_idx` (`id_local` ASC),
  INDEX `fk_kardex_transferencia1_idx` (`id_transferencia` ASC),
  CONSTRAINT `fk_cardex_compra1`
    FOREIGN KEY (`id_compra`)
    REFERENCES `compra` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_vendaos1`
    FOREIGN KEY (`id_vendaos`)
    REFERENCES `vendaos` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_cardex_usuario1`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_produto1`
    FOREIGN KEY (`id_produto`)
    REFERENCES `produto` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_empresa1`
    FOREIGN KEY (`id_empresa`)
    REFERENCES `empresa` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_local1`
    FOREIGN KEY (`id_local`)
    REFERENCES `local` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_kardex_transferencia1`
    FOREIGN KEY (`id_transferencia`)
    REFERENCES `transferencia` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;