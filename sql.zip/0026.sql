-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 15:40
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
CHANGE COLUMN `lojavirtual` `lojavirtual` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lojavirtualprincipal` `lojavirtualprincipal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `proximanota` `proximanota` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL ;

ALTER TABLE `expresso`.`usuario` 
CHANGE COLUMN `licenca` `licenca` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`cargo` 
CHANGE COLUMN `tecnico` `tecnico` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `vendedor` `vendedor` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `trocaempresa` `trocaempresa` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `custo` `custo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco1` `preco1` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco2` `preco2` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco3` `preco3` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco4` `preco4` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `preco5` `preco5` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`cidade` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`logradouro` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`logs` 
CHANGE COLUMN `upload` `upload` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`recurso` 
CHANGE COLUMN `tipo` `tipo` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`privilegio` 
CHANGE COLUMN `tipo` `tipo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `visivel` `visivel` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `novo` `novo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `editar` `editar` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluir` `excluir` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `imprimir` `imprimir` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `exportar` `exportar` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `logs` `logs` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lixeira` `lixeira` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `fechamento` `fechamento` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`contato` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `restricao` `restricao` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`categoria` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`servico` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`produto` 
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`marca` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`modelo` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`estoque` 
CHANGE COLUMN `minimo` `minimo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `lojavirtual` `lojavirtual` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`local` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`fisico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`proposta` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`propostaservico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`propostaproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compra` 
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `fechado` `fechado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `trafrete` `trafrete` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `traquant` `traquant` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
CHANGE COLUMN `prioridade` `prioridade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `autorizado` `autorizado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `entregue` `entregue` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `fechado` `fechado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `trafrete` `trafrete` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `traquant` `traquant` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contribuinte` `contribuinte` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `presencial` `presencial` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `consumidorfinal` `consumidorfinal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ,
ADD INDEX `fk_vendaos_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_vendaos_natureza1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `quantmax` `quantmax` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_local1_idx` (`id_local` ASC),
DROP INDEX `fk_vendaosproduto_local1_idx` ;

ALTER TABLE `expresso`.`vendaosservico` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`vendaostecnico` 
CHANGE COLUMN `participacao` `participacao` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`ostipo` 
CHANGE COLUMN `prazo` `prazo` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osstatus` 
CHANGE COLUMN `interno` `interno` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`oslocal` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osocorrencia` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`osoperadora` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`transferencia` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `quantidade` `quantidade` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`pagar` 
CHANGE COLUMN `item` `item` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`receber` 
CHANGE COLUMN `item` `item` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `notanumero` `notanumero` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `boletoenviado` `boletoenviado` SMALLINT(6) NULL DEFAULT 0 ,
CHANGE COLUMN `boletobaixado` `boletobaixado` SMALLINT(6) NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`plano` 
CHANGE COLUMN `disponivel` `disponivel` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`conta` 
CHANGE COLUMN `banco` `banco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `agencia` `agencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `agenciadv` `agenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `conta` `conta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contadv` `contadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `carteira` `carteira` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `variacao` `variacao` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `contrato` `contrato` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `protesto` `protesto` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `remessa` `remessa` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `aceite` `aceite` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`meio` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`lancamento` 
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`lancamentoplano` 
CHANGE COLUMN `automatico` `automatico` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `porcentagem` `porcentagem` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `tipolan` `tipolan` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`movimento` 
CHANGE COLUMN `tipolan` `tipolan` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`condicao` 
CHANGE COLUMN `diafixo` `diafixo` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`recebimentoitem` 
CHANGE COLUMN `chequebanco` `chequebanco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagencia` `chequeagencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagenciadv` `chequeagenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeconta` `chequeconta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequecontadv` `chequecontadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequenumero` `chequenumero` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`pagamentoitem` 
CHANGE COLUMN `chequebanco` `chequebanco` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagencia` `chequeagencia` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeagenciadv` `chequeagenciadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequeconta` `chequeconta` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequecontadv` `chequecontadv` SMALLINT(6) NULL DEFAULT NULL ,
CHANGE COLUMN `chequenumero` `chequenumero` SMALLINT(6) NULL DEFAULT NULL ;

ALTER TABLE `expresso`.`natureza` 
CHANGE COLUMN `compra` `compra` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `venda` `venda` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estoque` `estoque` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `financeiro` `financeiro` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `comissionado` `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `contribuinte` `contribuinte` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `presencial` `presencial` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `consumidorfinal` `consumidorfinal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

ALTER TABLE `expresso`.`regra` 
CHANGE COLUMN `icms` `icms` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `ipi` `ipi` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `pis` `pis` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `cofins` `cofins` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `issqn` `issqn` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `sub` `sub` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `difal` `difal` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estadodentro` `estadodentro` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `estadofora` `estadofora` SMALLINT(6) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `excluido` `excluido` SMALLINT(6) NOT NULL DEFAULT 0 ;

INSERT INTO atualizacao (id) VALUES (26);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
