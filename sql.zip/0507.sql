
ALTER TABLE `vendaos` 
ADD COLUMN `comissionado` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `consumidorfinal`;