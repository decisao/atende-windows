-- MySQL Workbench Synchronization
-- Generated: 2019-01-04 23:02
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `cardex` 
DROP COLUMN `cpfcnpj`,
DROP COLUMN `impostos`,
DROP COLUMN `valoroutros`,
DROP COLUMN `valorfrete`,
ADD COLUMN `estoque` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `customedio`,
ADD COLUMN `id_produto` BIGINT(11) NOT NULL AFTER `id_usuario`,
CHANGE COLUMN `nome` `nome` VARCHAR(60) NOT NULL AFTER `id`,
CHANGE COLUMN `tipo` `tipo` VARCHAR(20) NOT NULL AFTER `nome`,
CHANGE COLUMN `data` `data` DATETIME NOT NULL AFTER `tipo`,
CHANGE COLUMN `valorunitario` `customedio` DECIMAL(10,2) NOT NULL DEFAULT 0 ,
CHANGE COLUMN `total` `saldo` DECIMAL(10,2) NOT NULL DEFAULT 0 ,
ADD INDEX `fk_kardex_produto1_idx` (`id_produto` ASC);

RENAME TABLE `cardex` TO `kardex` ;

ALTER TABLE `compra` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`;

ALTER TABLE `vendaos` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`;

ALTER TABLE `privilegio` 
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechamento`;

ALTER TABLE `kardex` 
ADD CONSTRAINT `fk_kardex_produto1`
  FOREIGN KEY (`id_produto`)
  REFERENCES `produto` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
