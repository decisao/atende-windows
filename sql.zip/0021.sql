-- MySQL Workbench Synchronization
-- Generated: 2016-08-29 10:47
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compra` 
ADD COLUMN `id_natureza` BIGINT(11) NOT NULL AFTER `id_meio`,
ADD INDEX `fk_compra_natureza1_idx` (`id_natureza` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

ALTER TABLE `expresso`.`compra` 
ADD CONSTRAINT `fk_compra_natureza1`
  FOREIGN KEY (`id_natureza`)
  REFERENCES `expresso`.`natureza` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (21);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
