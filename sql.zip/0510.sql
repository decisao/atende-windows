
ALTER TABLE `cargo` 
ADD COLUMN `estoquenegativo` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `reabertura`,
ADD COLUMN `financeiroabaixo` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estoquenegativo`,
ADD COLUMN `idclone` BIGINT(11) NULL DEFAULT NULL AFTER `financeiroabaixo`;

ALTER TABLE `transferencia` 
ADD COLUMN `recebido` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `fechadopro`,
ADD COLUMN `recebidopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `recebido`,
ADD COLUMN `estorno` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `recebidopro`,
ADD COLUMN `estornopro` SMALLINT(6) NOT NULL DEFAULT 0 AFTER `estorno`,
ADD COLUMN `status` VARCHAR(60) NULL DEFAULT NULL AFTER `estornopro`;

ALTER TABLE `empresa` 
ADD COLUMN `lojavirtualtipo` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualprincipal`,
ADD COLUMN `lojavirtualusuario` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualtipo`,
ADD COLUMN `lojavirtualsenha` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualusuario`,
ADD COLUMN `lojavirtualchave` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualsenha`,
ADD COLUMN `contratoservico` LONGBLOB NULL DEFAULT NULL AFTER `certificadoa1`,
ADD COLUMN `contratoentradaos` LONGBLOB NULL DEFAULT NULL AFTER `contratoservico`,
ADD COLUMN `contratosaidaos` LONGBLOB NULL DEFAULT NULL AFTER `contratoentradaos`,
ADD COLUMN `contratochecklistos` LONGBLOB NULL DEFAULT NULL AFTER `contratosaidaos`,
ADD COLUMN `contratovenda` LONGBLOB NULL DEFAULT NULL AFTER `contratochecklistos`,
ADD COLUMN `contratoproposta` LONGBLOB NULL DEFAULT NULL AFTER `contratovenda`,
ADD COLUMN `nfetipo` VARCHAR(20) NULL DEFAULT NULL AFTER `contratoproposta`,
ADD COLUMN `xmlcaminho` VARCHAR(60) NULL DEFAULT NULL AFTER `nfetipo`,
ADD COLUMN `pdfcaminho` VARCHAR(60) NULL DEFAULT NULL AFTER `xmlcaminho`;