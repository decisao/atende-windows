-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 19:00
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD COLUMN `certificadoserie` VARCHAR(60) NULL DEFAULT NULL AFTER `lojavirtualprincipal`,
ADD COLUMN `certificadosenha` VARCHAR(60) NULL DEFAULT NULL AFTER `certificadoserie`,
ADD COLUMN `proximanota` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `certificadosenha`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`natureza` 
ADD INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
DROP INDEX `fk_natureza_empresa1_idx` ;

ALTER TABLE `expresso`.`regra` 
ADD INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_regra_natureza1_idx` ;

INSERT INTO atualizacao (id) VALUES (18);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
