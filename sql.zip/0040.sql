-- MySQL Workbench Synchronization
-- Generated: 2016-09-05 14:40
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`empresa` 
ADD INDEX `fk_empresa_natureza1_idx` (`id_natureza` ASC),
DROP INDEX `fk_empresa_natureza1_idx` ;

ALTER TABLE `expresso`.`compatibilidade` 
ADD INDEX `fk_compatibilidade_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_compatibilidade_marca1_idx` ;

ALTER TABLE `expresso`.`proposta` 
ADD COLUMN `id_condicao` BIGINT(11) NULL DEFAULT NULL AFTER `id_usuario`,
ADD COLUMN `id_meio` BIGINT(11) NULL DEFAULT NULL AFTER `id_condicao`,
ADD INDEX `fk_proposta_condicao1_idx` (`id_condicao` ASC),
ADD INDEX `fk_proposta_meio1_idx` (`id_meio` ASC);

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD INDEX `fk_vendaos_marca1_idx` (`id_marca` ASC),
DROP INDEX `fk_vendaos_marca1_idx` ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC),
DROP INDEX `fk_vendaosproduto_regra1_idx` ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`proposta` 
ADD CONSTRAINT `fk_proposta_condicao1`
  FOREIGN KEY (`id_condicao`)
  REFERENCES `expresso`.`condicao` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_proposta_meio1`
  FOREIGN KEY (`id_meio`)
  REFERENCES `expresso`.`meio` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (40);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
