-- MySQL Workbench Synchronization
-- Generated: 2016-08-30 17:58
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `id_regra` BIGINT(11) NULL DEFAULT NULL AFTER `id_local`,
ADD INDEX `fk_vendaosproduto_regra1_idx` (`id_regra` ASC);

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaosproduto` 
ADD CONSTRAINT `fk_vendaosproduto_regra1`
  FOREIGN KEY (`id_regra`)
  REFERENCES `expresso`.`regra` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO atualizacao (id) VALUES (29);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
