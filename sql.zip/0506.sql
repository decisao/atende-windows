
ALTER TABLE `kardex` 
 ADD COLUMN `serie` VARCHAR(60) NOT NULL DEFAULT "*" AFTER `quantidade`;