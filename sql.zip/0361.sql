
ALTER TABLE `pagar` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `receber` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;

ALTER TABLE `vendaos` 
CHANGE COLUMN `notanumero` `notanumero` BIGINT(11) NULL DEFAULT NULL ;
