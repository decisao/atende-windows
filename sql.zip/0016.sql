-- MySQL Workbench Synchronization
-- Generated: 2016-08-28 11:38
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `expresso`.`ncm` 
ADD COLUMN `federalnac` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `descricao`,
ADD COLUMN `federalimp` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalnac`,
ADD COLUMN `estadual` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `federalimp`,
ADD COLUMN `municipal` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `estadual`;

ALTER TABLE `expresso`.`compraproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`vendaos` 
ADD COLUMN `contribuinte` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `trapesoliquido`,
ADD COLUMN `presencial` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `contribuinte`,
ADD COLUMN `consumidorfinal` SMALLINT(1) NOT NULL DEFAULT 0 AFTER `presencial`;

ALTER TABLE `expresso`.`vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

ALTER TABLE `expresso`.`transferenciaproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ;

CREATE TABLE IF NOT EXISTS `expresso`.`natureza` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `compra` SMALLINT(1) NOT NULL DEFAULT 0,
  `venda` SMALLINT(1) NOT NULL DEFAULT 0,
  `estoque` SMALLINT(1) NOT NULL DEFAULT 0,
  `financeiro` SMALLINT(1) NOT NULL DEFAULT 0,
  `comissionado` SMALLINT(1) NOT NULL DEFAULT 0,
  `contribuinte` SMALLINT(1) NOT NULL DEFAULT 0,
  `presencial` SMALLINT(1) NOT NULL DEFAULT 0,
  `consumidorfinal` SMALLINT(1) NOT NULL DEFAULT 0,
  `excluido` SMALLINT(1) NOT NULL DEFAULT 0,
  `id_empresa` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_natureza_empresa1_idx` (`id_empresa` ASC),
  CONSTRAINT `fk_natureza_empresa1`
    FOREIGN KEY (`id_empresa`)
    REFERENCES `expresso`.`empresa` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `expresso`.`regra` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `cst` VARCHAR(10) NOT NULL DEFAULT 0,
  `csosn` VARCHAR(10) NOT NULL DEFAULT 0,
  `cfop` VARCHAR(10) NOT NULL DEFAULT 0,
  `icms` SMALLINT(1) NOT NULL DEFAULT 0,
  `icmsaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `ipi` SMALLINT(1) NOT NULL DEFAULT 0,
  `ipialiq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `pis` SMALLINT(1) NOT NULL DEFAULT 0,
  `pisaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `cofins` SMALLINT(1) NOT NULL DEFAULT 0,
  `cofinsaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `issqn` SMALLINT(1) NOT NULL DEFAULT 0,
  `issqnaliq` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `tiponota` VARCHAR(10) NOT NULL,
  `datainicio` DATE NOT NULL,
  `datafim` DATE NOT NULL,
  `sub` SMALLINT(1) NOT NULL DEFAULT 0,
  `difal` SMALLINT(1) NOT NULL DEFAULT 0,
  `icmsorigem` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `icmsdestino` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `icmspartilha` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `estadodentro` SMALLINT(1) NOT NULL DEFAULT 0,
  `estadofora` SMALLINT(1) NOT NULL DEFAULT 0,
  `estados` VARCHAR(512) NULL DEFAULT NULL,
  `excluido` SMALLINT(1) NOT NULL DEFAULT 0,
  `id_natureza` BIGINT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_regra_natureza1_idx` (`id_natureza` ASC),
  CONSTRAINT `fk_regra_natureza1`
    FOREIGN KEY (`id_natureza`)
    REFERENCES `expresso`.`natureza` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

INSERT INTO atualizacao (id) VALUES (16);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
