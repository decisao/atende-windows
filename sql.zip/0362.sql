
ALTER TABLE `empresa` 
ADD COLUMN `certificadoa1` LONGBLOB NULL DEFAULT NULL AFTER `imglogo`;