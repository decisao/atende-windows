-- MySQL Workbench Synchronization
-- Generated: 2018-03-03 19:23
-- Model: Expresso
-- Version: 1.0
-- Project: Expresso
-- Author: Elieser

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER TABLE `servico` 
ADD COLUMN `id_servicotipo` BIGINT(11) NULL DEFAULT NULL AFTER `excluido`,
ADD INDEX `fk_servico_servicotipo1_idx` (`id_servicotipo` ASC);

ALTER TABLE `vendaosproduto` 
CHANGE COLUMN `serie` `serie` VARCHAR(60) NOT NULL DEFAULT "*" ,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_regra`,
ADD INDEX `fk_vendaosproduto_usuario1_idx` (`id_usuario` ASC);

ALTER TABLE `vendaosservico` 
ADD COLUMN `percentualtecnico` DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER `total`,
ADD COLUMN `id_usuario` BIGINT(11) NOT NULL AFTER `id_servico`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `id_usuario`),
ADD INDEX `fk_vendaosservico_usuario1_idx` (`id_usuario` ASC);

CREATE TABLE IF NOT EXISTS `servicotipo` (
  `id` BIGINT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(60) NOT NULL,
  `percentual` DECIMAL(10,3) NOT NULL DEFAULT 0,
  `excluido` SMALLINT(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

ALTER TABLE `servico` 
ADD CONSTRAINT `fk_servico_servicotipo1`
  FOREIGN KEY (`id_servicotipo`)
  REFERENCES `servicotipo` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `vendaosproduto` 
ADD CONSTRAINT `fk_vendaosproduto_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `vendaosservico` 
ADD CONSTRAINT `fk_vendaosservico_usuario1`
  FOREIGN KEY (`id_usuario`)
  REFERENCES `usuario` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
